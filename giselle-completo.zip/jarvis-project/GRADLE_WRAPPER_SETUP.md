# gradle-wrapper.jar — RESOLVIDO

O `.jar` já está em `gradle/wrapper/gradle-wrapper.jar`, copiado de um
wrapper padrão do Gradle e com integridade verificada (o `.jar` é só o
bootstrapper — funciona com qualquer versão que o `gradle-wrapper.properties`
apontar, que aqui continua pedindo Gradle 8.7).

Não precisa rodar mais nada manualmente para isso. Se um dia quiser
trocar a versão do Gradle, edite só o `distributionUrl` em
`gradle-wrapper.properties` — o `.jar` não muda.
