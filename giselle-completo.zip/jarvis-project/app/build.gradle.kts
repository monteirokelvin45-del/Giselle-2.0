plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization") version "1.9.24"
    id("com.google.devtools.ksp") // para Room
}

android {
    namespace = "com.example.jarvis"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.jarvis"
        minSdk = 26          // Android 8.0 — mínimo viável para AccessibilityService robusto
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-skeleton"

        // Item 3: API key NUNCA hard-coded no código-fonte.
        // Lida de local.properties (arquivo fora do Git, .gitignore já
        // ignora por padrão em projetos Android) e injetada via BuildConfig.
        // Isso ainda expõe a key no APK compilado (qualquer um pode
        // decompilar e extrair) — para segurança real de produção,
        // veja a opção de backend proxy documentada no README.
        val localProps = java.util.Properties().apply {
            val file = rootProject.file("local.properties")
            if (file.exists()) load(file.inputStream())
        }
        buildConfigField(
            "String", "CLAUDE_API_KEY",
            "\"${localProps.getProperty("CLAUDE_API_KEY", "")}\""
        )
        buildConfigField(
            "String", "VOYAGE_API_KEY",
            "\"${localProps.getProperty("VOYAGE_API_KEY", "")}\""
        )
        buildConfigField(
            "String", "PICOVOICE_ACCESS_KEY",
            "\"${localProps.getProperty("PICOVOICE_ACCESS_KEY", "")}\""
        )
        buildConfigField(
            "String", "PROXY_BASE_URL",
            "\"${localProps.getProperty("PROXY_BASE_URL", "")}\""
        )
        // Precisa bater com PROXY_SHARED_SECRET configurado no Worker
        // (wrangler secret put PROXY_SHARED_SECRET) — sem isso o proxy
        // responde 401. Só é usado quando PROXY_BASE_URL está setado.
        buildConfigField(
            "String", "PROXY_SHARED_SECRET",
            "\"${localProps.getProperty("PROXY_SHARED_SECRET", "")}\""
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Core Android + Compose
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("com.patrykandpatrick.vico:compose-m3:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")

    // Rede (Claude API, Voyage embeddings)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Serialização JSON (contrato estruturado do LLM)
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")

    // Persistência local (memória de longo prazo)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Coroutines (orquestração assíncrona)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Item 6: wake word contínuo (opcional — requer AccessKey da Picovoice
    // e um modelo .ppn customizado em app/src/main/assets/, ver WakeWordService.kt)
    // Voz offline (wake word + STT) — substitui o Porcupine (que exigia chave/modelo na Picovoice)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    // LLM local (opcional, carregado por reflexão): descomenta e põe local-llm.task no app.
    // implementation("com.google.mediapipe:tasks-genai:0.10.14")

    // Testes
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
    testImplementation("org.robolectric:robolectric:4.13")
    testImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
