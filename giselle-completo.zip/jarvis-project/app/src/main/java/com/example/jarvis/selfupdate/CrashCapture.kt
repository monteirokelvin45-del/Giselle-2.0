// ============================================================
// selfupdate/CrashCapture.kt
// ------------------------------------------------------------
// Captura toda exceção não tratada do app (crash) e qualquer
// erro logado explicitamente (ex: falha de parsing, resposta
// inesperada da API) — sem nunca corrigir nada sozinho aqui.
// Este arquivo só OBSERVA e GRAVA. A decisão de diagnosticar
// e sugerir correção vive em SelfDiagnosisAgent.kt, separado
// de propósito: quem detecta o erro não é quem decide o que
// fazer com ele.
// ============================================================

package com.example.jarvis.selfupdate

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "error_log")
data class ErrorLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val tipo: String,              // "crash_fatal" | "erro_capturado"
    val threadName: String,
    val exceptionClass: String,
    val message: String?,
    val stackTrace: String,
    val telaAtual: String?,        // qual tela/módulo estava ativo, se souber
    val versaoApp: String,
    val diagnosticado: Boolean = false
)

@Dao
interface ErrorLogDao {
    @Insert
    suspend fun insert(error: ErrorLogEntity): Long

    @Query("SELECT * FROM error_log WHERE diagnosticado = 0 ORDER BY timestamp DESC")
    fun pendentesDeDiagnostico(): Flow<List<ErrorLogEntity>>

    @Query("SELECT * FROM error_log ORDER BY timestamp DESC LIMIT :limite")
    fun recentes(limite: Int = 50): Flow<List<ErrorLogEntity>>

    @Query("UPDATE error_log SET diagnosticado = 1 WHERE id = :id")
    suspend fun marcarDiagnosticado(id: Long)
}

/**
 * Registra-se como handler global de crash. Não impede o crash
 * (isso seria mascarar o problema) — só garante que a informação
 * sobrevive ao restart do app pra poder ser diagnosticada depois.
 */
class CrashCaptureHandler(
    private val context: Context,
    private val dao: ErrorLogDao,
    private val versaoApp: String,
    private val original: Thread.UncaughtExceptionHandler?
) : Thread.UncaughtExceptionHandler {

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            // gravação síncrona e simples de propósito — o processo
            // está morrendo, não é hora de coroutine ou I/O complexo
            val db = androidx.room.Room.databaseBuilder(
                context.applicationContext,
                com.example.jarvis.selfupdate.SelfUpdateDatabaseHolder.dbClass,
                "selfupdate.db"
            ).build()
            db.errorLogDao().let {
                kotlinx.coroutines.runBlocking {
                    it.insert(
                        ErrorLogEntity(
                            timestamp = System.currentTimeMillis(),
                            tipo = "crash_fatal",
                            threadName = thread.name,
                            exceptionClass = throwable::class.qualifiedName ?: "Desconhecida",
                            message = throwable.message,
                            stackTrace = throwable.stackTraceToString(),
                            telaAtual = null,
                            versaoApp = versaoApp
                        )
                    )
                }
            }
        } catch (_: Throwable) {
            // se a própria captura falhar, não podemos deixar isso
            // impedir o crash original de seguir seu curso normal
        }
        original?.uncaughtException(thread, throwable)
    }

    companion object {
        fun install(context: Context, dao: ErrorLogDao, versaoApp: String) {
            val original = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler(
                CrashCaptureHandler(context, dao, versaoApp, original)
            )
        }
    }
}

/** Ponto único de referência pra classe do Database, evita import circular. */
object SelfUpdateDatabaseHolder {
    lateinit var dbClass: Class<out RoomDatabase>
}

/**
 * Uso fora de crash fatal: erros capturados via try/catch que você
 * julga relevantes registrar (ex: parsing de resposta da IA falhou,
 * uma chamada de rede retornou formato inesperado). Chame explicitamente
 * onde fizer sentido — isso não substitui tratamento de erro normal,
 * só alimenta o diagnóstico posterior.
 */
suspend fun registrarErroCapturado(
    dao: ErrorLogDao,
    throwable: Throwable,
    tela: String,
    versaoApp: String
) {
    dao.insert(
        ErrorLogEntity(
            timestamp = System.currentTimeMillis(),
            tipo = "erro_capturado",
            threadName = Thread.currentThread().name,
            exceptionClass = throwable::class.qualifiedName ?: "Desconhecida",
            message = throwable.message,
            stackTrace = throwable.stackTraceToString(),
            telaAtual = tela,
            versaoApp = versaoApp
        )
    )
}
