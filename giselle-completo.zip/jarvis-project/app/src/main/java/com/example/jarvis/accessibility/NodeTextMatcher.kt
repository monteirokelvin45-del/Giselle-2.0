// ============================================================
// accessibility/NodeTextMatcher.kt
// ------------------------------------------------------------
// Lógica pura de busca de texto numa árvore, extraída de
// JarvisAccessibilityService.findNodeByText para ser testável
// sem AccessibilityNodeInfo/Android real.
// ============================================================

package com.example.jarvis.accessibility

/** Visão simplificada e imutável de um nó de tela, independente de Android. */
data class NodeView(val text: String?, val children: List<NodeView> = emptyList())

object NodeTextMatcher {
    fun find(node: NodeView, target: String): NodeView? {
        if (node.text?.contains(target, ignoreCase = true) == true) return node
        for (child in node.children) {
            find(child, target)?.let { return it }
        }
        return null
    }
}
