// ============================================================
// memory/MemoryStore.kt
// ------------------------------------------------------------
// Memória de longo prazo. Isso é o que faz o Jarvis "evoluir":
// cada correção do usuário, cada padrão repetido, vira uma
// entrada aqui com peso de confiança que cresce ou decai.
//
// Implementação: Room (SQLite) para persistência local,
// com um índice de embeddings simplificado em memória para
// busca por similaridade (troque por um vetor DB real como
// ObjectBox Vector ou SQLite+sqlite-vec se escalar).
// ============================================================

package com.example.jarvis.memory

import androidx.room.*
import com.example.jarvis.core.AuditLogDao
import com.example.jarvis.core.AuditLogEntity
import com.example.jarvis.core.MemoryCategory
import com.example.jarvis.core.MemoryEntry
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import kotlin.math.sqrt

// -----------------------------------------------------
// Entidade Room (persistência)
// -----------------------------------------------------
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val content: String,
    val category: String,
    val embeddingCsv: String,   // embedding serializado como CSV de floats
    val createdAt: Long,
    val lastReinforced: Long,
    val confidence: Float
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY lastReinforced DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories")
    suspend fun getAll(): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE memories SET confidence = :confidence, lastReinforced = :ts WHERE id = :id")
    suspend fun reinforce(id: String, confidence: Float, ts: Long)
}

@Database(entities = [MemoryEntity::class, AuditLogEntity::class], version = 1)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun auditLogDao(): AuditLogDao
}

// -----------------------------------------------------
// API de alto nível usada pelo Orchestrator
// -----------------------------------------------------
class MemoryStore(
    private val dao: MemoryDao,
    private val embedder: TextEmbedder
) {

    /**
     * Salva uma nova memória. CORRECTION tem peso inicial mais alto
     * porque representa o usuário ativamente ensinando o sistema.
     */
    suspend fun remember(content: String, category: MemoryCategory) {
        val embedding = embedder.embed(content)
        val initialConfidence = when (category) {
            MemoryCategory.CORRECTION -> 0.9f
            MemoryCategory.FACT -> 0.85f
            else -> 0.6f
        }
        dao.upsert(
            MemoryEntity(
                id = UUID.randomUUID().toString(),
                content = content,
                category = category.name,
                embeddingCsv = embedding.joinToString(","),
                createdAt = System.currentTimeMillis(),
                lastReinforced = System.currentTimeMillis(),
                confidence = initialConfidence
            )
        )
    }

    /**
     * Busca as memórias mais relevantes para o contexto atual,
     * por similaridade de cosseno. É isso que dá "continuidade"
     * ao raciocínio do LLM entre sessões diferentes.
     *
     * Query em branco = listagem geral (usada pela tela de Memórias),
     * sem aplicar o filtro de relevância semântica.
     */
    suspend fun recall(query: String, topK: Int = 5): List<MemoryEntry> {
        val all = dao.getAll()
        if (query.isBlank()) {
            return all.sortedByDescending { it.lastReinforced }
                .take(topK)
                .map { it.toMemoryEntry() }
        }

        val queryEmbedding = embedder.embed(query)
        return all.map { entity ->
            val entityEmbedding = entity.embeddingCsv.split(",").map { it.toFloat() }.toFloatArray()
            val similarity = cosineSimilarity(queryEmbedding, entityEmbedding)
            entity to similarity
        }
            .sortedByDescending { it.second }
            .take(topK)
            .filter { it.second > 0.3f } // threshold mínimo de relevância
            .map { (entity, _) -> entity.toMemoryEntry() }
    }

    /**
     * Reforça uma memória existente quando o padrão se repete
     * (aumenta confiança) — é assim que o sistema "aprende" de fato,
     * distinguindo coincidência de hábito consistente.
     */
    suspend fun reinforce(memoryId: String, currentConfidence: Float) {
        val newConfidence = (currentConfidence + (1 - currentConfidence) * 0.2f).coerceAtMost(0.99f)
        dao.reinforce(memoryId, newConfidence, System.currentTimeMillis())
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float = VectorMath.cosineSimilarity(a, b)

    private fun MemoryEntity.toMemoryEntry() = MemoryEntry(
        id = id,
        content = content,
        category = MemoryCategory.valueOf(category),
        createdAt = createdAt,
        lastReinforced = lastReinforced,
        confidence = confidence
    )
}

// -----------------------------------------------------
// Interface de embedding — trocável (local ou via API)
// -----------------------------------------------------
interface TextEmbedder {
    suspend fun embed(text: String): FloatArray
}
