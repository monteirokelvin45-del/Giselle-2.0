package com.example.jarvis.vision

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import androidx.annotation.RequiresApi
import com.example.jarvis.accessibility.JarvisAccessibilityService
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Screenshot: API 30+ via AccessibilityService (sem diálogo); abaixo disso, MediaProjection (ProjectionService). */
object ScreenCapture {
    suspend fun capture(): Bitmap? {
        val svc = JarvisAccessibilityService.instance
        if (Build.VERSION.SDK_INT >= 30 && svc != null) viaAccessibility(svc)?.let { return it }
        return ProjectionService.latestFrame()
    }

    @RequiresApi(30)
    private suspend fun viaAccessibility(svc: AccessibilityService): Bitmap? =
        suspendCancellableCoroutine { cont ->
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, svc.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    val bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    if (cont.isActive) cont.resume(bmp)
                }
                override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(null) }
            })
        }
}
