package com.example.jarvis.routine

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.jarvis.core.GiselleBus
import com.example.jarvis.ledger.Ledger
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

object DailyBrief {
    data class Ev(val title: String, val begin: Long)

    private fun events(ctx: Context, from: Long, to: Long): List<Ev> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, from); ContentUris.appendId(b, to)
        val out = ArrayList<Ev>()
        runCatching {
            ctx.contentResolver.query(
                b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, "${CalendarContract.Instances.BEGIN} ASC"
            )?.use { c -> while (c.moveToNext()) out += Ev(c.getString(0) ?: "(sem título)", c.getLong(1)) }
        }
        return out
    }

    fun upcoming(ctx: Context, fromMin: Int, toMin: Int): List<Ev> {
        val now = System.currentTimeMillis()
        return events(ctx, now + fromMin * 60_000L, now + toMin * 60_000L)
    }

    fun build(ctx: Context): String {
        val loc = Locale("pt", "MZ")
        val day = SimpleDateFormat("EEEE, d 'de' MMMM", loc).format(Calendar.getInstance().time)
        val start = Ledger.startOfDay()
        val evs = events(ctx, System.currentTimeMillis(), start + 24 * 3600_000L)
        val hm = SimpleDateFormat("HH:mm", loc)
        val agenda = if (evs.isEmpty()) "Sem compromissos na agenda."
        else "Tens ${evs.size} compromisso${if (evs.size > 1) "s" else ""}: " +
            evs.take(4).joinToString("; ") { "${it.title} às ${hm.format(it.begin)}" } + "."
        val y = Ledger.total(ctx, Ledger.startOfDay(1), start)
        val money = if (y > 0) " Ontem gastaste ${"%.0f".format(y)} MT." else ""
        val week = if (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY)
            " " + Ledger.report(ctx, "semana") else ""
        return "Bom dia! Hoje é $day. $agenda$money$week"
    }

    /** Verifica a cada ~15 min se vem aí um compromisso (proatividade). */
    fun scheduleProactive(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            "proactive", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ProactiveWorker>(15, TimeUnit.MINUTES).build()
        )
    }
}

class ProactiveWorker(private val ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val prefs = ctx.getSharedPreferences("giselle_proactive", Context.MODE_PRIVATE)
        val seen = prefs.getStringSet("seen", emptySet()) ?: emptySet()
        val soon = DailyBrief.upcoming(ctx, 5, 25).filter { "${it.begin}:${it.title}" !in seen }
        if (soon.isEmpty()) return Result.success()
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("giselle_routines", "Giselle (rotinas)", NotificationManager.IMPORTANCE_HIGH))
        soon.forEach { ev ->
            val mins = ((ev.begin - System.currentTimeMillis()) / 60_000L).coerceAtLeast(1)
            val msg = "Faltam $mins minutos para ${ev.title}"
            nm.notify(ev.title.hashCode(), NotificationCompat.Builder(ctx, "giselle_routines")
                .setContentTitle("Giselle").setContentText(msg).setSmallIcon(android.R.drawable.ic_popup_reminder).setAutoCancel(true).build())
            GiselleBus.announce(msg)
        }
        prefs.edit().putStringSet("seen", (seen + soon.map { "${it.begin}:${it.title}" }).toList().takeLast(40).toSet()).apply()
        return Result.success()
    }
}
