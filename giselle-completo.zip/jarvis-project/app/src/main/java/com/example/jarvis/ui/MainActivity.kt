// ============================================================
// ui/MainActivity.kt
// ------------------------------------------------------------
// Tela única com 3 abas: Comando (chat + voz), Confirmações
// pendentes, e Memórias aprendidas. É por aqui que você
// efetivamente USA o Jarvis.
// ============================================================

package com.example.jarvis.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.jarvis.agent.PendingAction
import com.example.jarvis.BuildConfig
import com.example.jarvis.core.FeedItem
import com.example.jarvis.core.FeedItemType
import com.example.jarvis.core.JarvisForegroundService
import com.example.jarvis.core.JarvisRepository
import com.example.jarvis.core.MemoryEntry
import com.example.jarvis.llm.TrackerInsightClient
import com.example.jarvis.core.CircuitBreaker
import com.example.jarvis.core.RateLimiter
import com.example.jarvis.tracker.agent.TrackerFeedback
import com.example.jarvis.tracker.agent.TrackerOrchestrator
import com.example.jarvis.tracker.agent.TrackerRepository
import com.example.jarvis.tracker.data.TrackerDatabase
import com.example.jarvis.tracker.onboarding.OnboardingScreen
import com.example.jarvis.tracker.onboarding.OnboardingViewModelFactory
import com.example.jarvis.tracker.ui.TrackerScreen
import com.example.jarvis.voice.VoiceEngine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private lateinit var voiceEngine: VoiceEngine
    private lateinit var trackerOrchestrator: TrackerOrchestrator

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* resultado tratado no fluxo normal da tela */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voiceEngine = VoiceEngine(applicationContext).apply { init() }

        requestNeededPermissions()
        ensureServiceStarted()
        setupTrackerOrchestrator()

        // Item 6: se detectado "Jarvis" em background, aciona escuta
        // de comando automaticamente — sem precisar tocar no microfone.
        com.example.jarvis.voice.WakeWordService.onWakeWordDetected = {
            runOnUiThread {
                voiceEngine.listenOnce(
                    onResult = { text -> sendCommand(text) },
                    onError = { }
                )
            }
        }

        setContent {
            MaterialTheme {
                var onboardingDone by remember { mutableStateOf<Boolean?>(null) }
                var trackerMoeda by remember { mutableStateOf("MZN") }

                LaunchedEffect(Unit) {
                    val perfil = TrackerDatabase.getInstance(applicationContext).configPerfilDao().get()
                    onboardingDone = perfil?.status == "confirmado"
                    trackerMoeda = perfil?.moeda ?: "MZN"
                }

                when (onboardingDone) {
                    null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    false -> OnboardingScreen(
                        factory = OnboardingViewModelFactory(TrackerDatabase.getInstance(applicationContext)),
                        onFinished = {
                            onboardingDone = true
                            lifecycleScope.launch {
                                trackerMoeda = TrackerDatabase.getInstance(applicationContext)
                                    .configPerfilDao().get()?.moeda ?: "MZN"
                            }
                        }
                    )
                    true -> JarvisApp(
                        voiceEngine = voiceEngine,
                        isAccessibilityEnabled = { isAccessibilityServiceEnabled() },
                        onOpenAccessibilitySettings = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onSendCommand = { command -> sendCommand(command) },
                        onResolveConfirmation = { pending, approved -> resolveConfirmation(pending, approved) },
                        onRefreshMemories = { refreshMemories() },
                        onGenerateInsight = {
                            TrackerRepository.setStatusMessage("Analisando seus dados...")
                            trackerOrchestrator.generateInsight()
                        },
                        onResolveInsightFeedback = { eventId, feedback ->
                            TrackerRepository.markResolvedLocally(eventId, feedback.name.lowercase())
                            trackerOrchestrator.resolveInsightFeedback(eventId, feedback)
                        },
                        registroFisicoDao = TrackerDatabase.getInstance(applicationContext).registroFisicoDao(),
                        registroFinanceiroDao = TrackerDatabase.getInstance(applicationContext).registroFinanceiroDao(),
                        moedaPadrao = trackerMoeda
                    )
                }
            }
        }
    }

    private fun setupTrackerOrchestrator() {
        val db = TrackerDatabase.getInstance(applicationContext)
        val insightClient = TrackerInsightClient(apiKey = BuildConfig.CLAUDE_API_KEY)

        trackerOrchestrator = TrackerOrchestrator(
            claude = insightClient,
            configPerfilDao = db.configPerfilDao(),
            metasDao = db.metasDao(),
            registroFisicoDao = db.registroFisicoDao(),
            registroMentalDao = db.registroMentalDao(),
            registroEstudoDao = db.registroEstudoDao(),
            registroFinanceiroDao = db.registroFinanceiroDao(),
            aiEventDao = db.aiEventDao(),
            rateLimiter = RateLimiter(maxCallsPerWindow = 10, windowMs = 60_000L),
            circuitBreaker = CircuitBreaker(failureThreshold = 3, openDurationMs = 60_000L),
            onInsightGenerated = { event ->
                runOnUiThread {
                    TrackerRepository.setStatusMessage(null)
                    TrackerRepository.addInsight(event)
                }
            },
            onCircuitOpen = { reason ->
                runOnUiThread { TrackerRepository.setStatusMessage(reason) }
            },
            onInsufficientData = { reason ->
                runOnUiThread { TrackerRepository.setStatusMessage(reason) }
            }
        )
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private val projectionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { r ->
        r.data?.let { com.example.jarvis.vision.ProjectionService.start(this, r.resultCode, it) }
    }

    private fun startVoiceIfPermitted() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            ContextCompat.startForegroundService(this, Intent(this, com.example.jarvis.voice.WakeWordService::class.java))
        }
    }

    // Android < 11 não tem screenshot por acessibilidade: pede captura de ecrã (1x por sessão).
    private fun requestVisionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT < 30 && !com.example.jarvis.vision.ProjectionService.running) {
            val mpm = getSystemService(android.media.projection.MediaProjectionManager::class.java)
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    override fun onResume() {
        super.onResume()
        startVoiceIfPermitted()
    }

    private fun ensureServiceStarted() {
        val intent = Intent(this, JarvisForegroundService::class.java)
        ContextCompat.startForegroundService(this, intent)
        startVoiceIfPermitted()
        requestVisionIfNeeded()
    }

    private fun sendCommand(command: String) {
        val intent = Intent(this, JarvisForegroundService::class.java).apply {
            action = JarvisForegroundService.ACTION_USER_COMMAND
            putExtra(JarvisForegroundService.EXTRA_COMMAND, command)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun resolveConfirmation(pending: PendingAction, approved: Boolean) {
        val intent = Intent(this, JarvisForegroundService::class.java).apply {
            action = JarvisForegroundService.ACTION_RESOLVE_CONFIRMATION
            putExtra(JarvisForegroundService.EXTRA_APPROVED, approved)
            putExtra(JarvisForegroundService.EXTRA_PENDING_CREATED_AT, pending.createdAt)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun refreshMemories() {
        val intent = Intent(this, JarvisForegroundService::class.java).apply {
            action = JarvisForegroundService.ACTION_REFRESH_MEMORIES
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "${packageName}/${packageName}.accessibility.JarvisAccessibilityService"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(expected)
    }

    override fun onDestroy() {
        voiceEngine.destroy()
        super.onDestroy()
    }
}

// ============================================================
// COMPOSABLES
// ============================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisApp(
    voiceEngine: VoiceEngine,
    isAccessibilityEnabled: () -> Boolean,
    onOpenAccessibilitySettings: () -> Unit,
    onSendCommand: (String) -> Unit,
    onResolveConfirmation: (PendingAction, Boolean) -> Unit,
    onRefreshMemories: () -> Unit,
    onGenerateInsight: () -> Unit,
    onResolveInsightFeedback: (Long, TrackerFeedback) -> Unit,
    registroFisicoDao: com.example.jarvis.tracker.data.RegistroFisicoDao,
    registroFinanceiroDao: com.example.jarvis.tracker.data.RegistroFinanceiroDao,
    moedaPadrao: String
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val pendingActions by JarvisRepository.pendingActions.collectAsStateWithLifecycle()
    val accessibilityOn = remember { isAccessibilityEnabled() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Jarvis", fontWeight = FontWeight.Bold) },
                actions = {
                    if (pendingActions.isNotEmpty()) {
                        Badge(containerColor = Color(0xFFE53935)) {
                            Text("${pendingActions.size}")
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Filled.Send, contentDescription = "Comando") },
                    label = { Text("Comando") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Filled.Mic, contentDescription = "Confirmações") },
                    label = { Text("Confirmações" + if (pendingActions.isNotEmpty()) " (${pendingActions.size})" else "") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2; onRefreshMemories() },
                    icon = { Icon(Icons.Filled.Send, contentDescription = "Memórias") },
                    label = { Text("Memórias") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Filled.Send, contentDescription = "Tracker") },
                    label = { Text("Tracker") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Filled.Send, contentDescription = "Registrar") },
                    label = { Text("Registrar") }
                )
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (!accessibilityOn) {
                AccessibilityWarningBanner(onOpenAccessibilitySettings)
            }
            when (selectedTab) {
                0 -> CommandScreen(voiceEngine, onSendCommand)
                1 -> ConfirmationsScreen(pendingActions, onResolveConfirmation)
                2 -> MemoriesScreen()
                3 -> com.example.jarvis.tracker.ui.TrackerScreen(
                    onGenerateInsight = onGenerateInsight,
                    onResolveFeedback = onResolveInsightFeedback
                )
                4 -> RegistrarTabScreen(registroFisicoDao, registroFinanceiroDao, moedaPadrao)
            }
        }
    }
}

@Composable
fun RegistrarTabScreen(
    registroFisicoDao: com.example.jarvis.tracker.data.RegistroFisicoDao,
    registroFinanceiroDao: com.example.jarvis.tracker.data.RegistroFinanceiroDao,
    moedaPadrao: String
) {
    var subTab by remember { mutableIntStateOf(0) }
    var savedMessage by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Físico") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Financeiro") })
        }

        savedMessage?.let {
            Surface(color = Color(0xFFE8F5E9), modifier = Modifier.fillMaxWidth()) {
                Text(it, Modifier.padding(12.dp))
            }
        }

        when (subTab) {
            0 -> com.example.jarvis.tracker.ui.RegistroFisicoScreen(
                dao = registroFisicoDao,
                onSaved = { savedMessage = "Registro físico salvo." }
            )
            1 -> com.example.jarvis.tracker.ui.RegistroFinanceiroScreen(
                dao = registroFinanceiroDao,
                moedaPadrao = moedaPadrao,
                onSaved = { savedMessage = "Transação salva." }
            )
        }
    }
}

@Composable
fun AccessibilityWarningBanner(onOpenSettings: () -> Unit) {
    Surface(color = Color(0xFFFFF3CD), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Acessibilidade desativada — o Jarvis não consegue ler nem agir na tela ainda.",
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onOpenSettings) { Text("Ativar") }
        }
    }
}

@Composable
fun CommandScreen(voiceEngine: VoiceEngine, onSendCommand: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    val feed by JarvisRepository.feed.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            reverseLayout = true
        ) {
            items(feed.reversed()) { item -> FeedBubble(item) }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = {
                    isListening = true
                    voiceEngine.listenOnce(
                        onResult = { text ->
                            isListening = false
                            onSendCommand(text)
                        },
                        onError = { isListening = false }
                    )
                }
            ) {
                Icon(
                    Icons.Filled.Mic,
                    contentDescription = "Falar",
                    tint = if (isListening) Color.Red else MaterialTheme.colorScheme.primary
                )
            }

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Diga o que fazer...") },
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (input.isNotBlank()) {
                        onSendCommand(input)
                        input = ""
                    }
                }
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Enviar")
            }
        }
    }
}

@Composable
fun FeedBubble(item: FeedItem) {
    val (bg, label) = when (item.type) {
        FeedItemType.INFO -> Color(0xFFE3F2FD) to null
        FeedItemType.ACTION_DONE -> Color(0xFFE8F5E9) to "✓ ação executada"
        FeedItemType.ACTION_FAILED -> Color(0xFFFFEBEE) to "✗ falhou"
        FeedItemType.CONFIRMATION_ASKED -> Color(0xFFFFF3E0) to "⏸ aguardando confirmação"
        FeedItemType.SPOKEN -> Color(0xFFF3E5F5) to null
    }
    val time = remember(item.timestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(item.timestamp))
    }

    Surface(color = bg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            if (label != null) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
            Text(item.text)
            Text(time, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}

@Composable
fun ConfirmationsScreen(
    pending: List<PendingAction>,
    onResolve: (PendingAction, Boolean) -> Unit
) {
    if (pending.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nenhuma confirmação pendente.", color = Color.Gray)
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(pending) { action ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(action.app, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                    Spacer(Modifier.height(4.dp))
                    Text(action.decision.userFacingSummary, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onResolve(action, true) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) { Text("Confirmar") }
                        OutlinedButton(onClick = { onResolve(action, false) }) { Text("Rejeitar") }
                    }
                }
            }
        }
    }
}

@Composable
fun MemoriesScreen() {
    val memories by JarvisRepository.memories.collectAsStateWithLifecycle()

    if (memories.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Ainda não há memórias registradas.", color = Color.Gray)
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(memories) { memory -> MemoryCard(memory) }
    }
}

@Composable
fun MemoryCard(memory: MemoryEntry) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(memory.category.name) })
                AssistChip(onClick = {}, label = { Text("conf. ${"%.0f".format(memory.confidence * 100)}%") })
            }
            Spacer(Modifier.height(6.dp))
            Text(memory.content)
        }
    }
}
