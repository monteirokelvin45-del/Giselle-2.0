// ============================================================
// memory/SimpleEmbedder.kt
// ------------------------------------------------------------
// Nota de engenharia honesta: a API da Anthropic não expõe
// endpoint de embeddings nativamente. Duas opções reais:
//
// 1) Usar um provedor de embeddings dedicado (Voyage AI é o
//    parceiro recomendado pela Anthropic para isso).
// 2) Rodar um embedder local leve no device (ex: modelo
//    sentence-transformers convertido pra TFLite/ONNX).
//
// Este arquivo traz a opção (1) via Voyage, com fallback
// hash-based simplificado só para prototipagem offline —
// NÃO use o fallback em produção, ele é só pra você testar
// o pipeline sem depender de outra API key ainda.
// ============================================================

package com.example.jarvis.memory

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class VoyageEmbedder(private val apiKey: String) : TextEmbedder {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .build()

    override suspend fun embed(text: String): FloatArray {
        val body = JSONObject().apply {
            put("input", JSONArray().put(text))
            put("model", "voyage-3-lite")
        }
        val request = Request.Builder()
            .url("https://api.voyageai.com/v1/embeddings")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Voyage embed falhou: ${response.code}")
            val json = JSONObject(response.body?.string().orEmpty())
            val embeddingArray = json.getJSONArray("data").getJSONObject(0).getJSONArray("embedding")
            return FloatArray(embeddingArray.length()) { i -> embeddingArray.getDouble(i).toFloat() }
        }
    }
}

/**
 * ATENÇÃO: apenas para desenvolvimento/teste sem API key extra.
 * Gera um pseudo-embedding determinístico via hashing — não captura
 * semântica real, só permite testar o pipeline de memória ponta a ponta
 * antes de plugar um embedder de verdade.
 */
class DevFallbackEmbedder : TextEmbedder {
    private val dimensions = 64

    override suspend fun embed(text: String): FloatArray {
        val digest = MessageDigest.getInstance("SHA-256").digest(text.lowercase().toByteArray())
        return FloatArray(dimensions) { i ->
            val byte = digest[i % digest.size]
            (byte.toFloat() / 127f)
        }
    }
}
