package com.example.jarvis.voice

import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Baixa e descompacta o modelo Vosk PT (~30 MB) uma única vez para filesDir/vosk-model. */
object ModelDownloader {
    private const val URL_MODEL = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip"

    fun download(filesDir: File, target: File): Boolean = try {
        val tmp = File(filesDir, "vosk-tmp").apply { deleteRecursively(); mkdirs() }
        val conn = URL(URL_MODEL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000; conn.readTimeout = 30_000
        ZipInputStream(conn.inputStream.buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(tmp, e.name)
                // proteção contra zip-slip
                if (!out.canonicalPath.startsWith(tmp.canonicalPath)) throw SecurityException("zip inválido")
                if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { zin.copyTo(it) } }
                e = zin.nextEntry
            }
        }
        val inner = tmp.listFiles()?.singleOrNull { it.isDirectory } ?: tmp
        target.deleteRecursively()
        val ok = inner.renameTo(target)
        tmp.deleteRecursively()
        ok
    } catch (e: Exception) {
        false
    }
}
