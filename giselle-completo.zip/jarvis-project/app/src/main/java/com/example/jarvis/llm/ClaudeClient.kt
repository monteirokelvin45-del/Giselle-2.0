// ============================================================
// llm/ClaudeClient.kt
// Integração com a Claude API. Recebe o contexto de percepção,
// devolve uma decisão estruturada (JSON forçado).
// ============================================================

package com.example.jarvis.llm

import com.example.jarvis.core.ActionType
import com.example.jarvis.core.AgentDecision
import com.example.jarvis.core.PerceptionContext
import kotlinx.coroutines.delay
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Resultado explícito em vez de exceção crua — obriga quem chama
 * a decidir o que fazer no caminho de falha (item 10: fallback).
 */
sealed class DecisionResult {
    data class Success(val decision: AgentDecision) : DecisionResult()
    data class Failure(val reason: String, val recoverable: Boolean) : DecisionResult()
}

class ClaudeClient(
    private val apiKey: String,
    private val model: String = "claude-sonnet-4-6",
    private val maxRetries: Int = 2,
    // Item 20: se configurado (via BuildConfig.PROXY_BASE_URL, de
    // local.properties), a key nunca sai do servidor — o app manda
    // a requisição pro proxy, não direto pra Anthropic. Sem isso
    // configurado, cai no comportamento anterior (key no APK via
    // BuildConfig, aceitável só para uso pessoal sideload).
    private val proxyBaseUrl: String? = null,
    // Precisa bater com PROXY_SHARED_SECRET configurado no Worker
    // (backend-proxy/worker.js). Sem isso, o proxy responde 401 —
    // é o que impede o Worker de virar um proxy aberto pra
    // qualquer um que descubra a URL.
    private val proxySharedSecret: String? = null
) {
    // Timeouts curtos de propósito: se a API travar, o usuário não
    // pode ficar esperando indefinidamente parado numa tela — o
    // orquestrador precisa poder desistir e devolver controle.
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    companion object {
        private const val ENDPOINT = "https://api.anthropic.com/v1/messages"

        // System prompt fixo: define o "caráter" e as regras do agente.
        // Isso NÃO decide segurança (isso é hard-coded no SafetyGate),
        // mas define como o LLM deve raciocinar e formatar a resposta.
        internal val SYSTEM_PROMPT = """
            Você é o motor de decisão de um assistente Android chamado Jarvis.
            Você recebe: o app atualmente em foco, uma leitura da tela (hierarquia
            de elementos visíveis), o comando do usuário (se houver), histórico
            recente de ações, e memórias relevantes de longo prazo sobre o usuário.

            Sua tarefa: decidir a PRÓXIMA ação única mais adequada para avançar
            o objetivo do usuário. Você NÃO decide se uma ação precisa de
            confirmação — isso é controlado por outro sistema. Apenas decida
            a ação correta e honesta com base no que está na tela.

            Responda ESTRITAMENTE em JSON, sem markdown, sem texto fora do JSON,
            seguindo exatamente este schema:
            {
              "reasoning": "string curta explicando o raciocínio",
              "actionType": "CLICK|TYPE_TEXT|SWIPE|OPEN_APP|GO_BACK|GO_HOME|WAIT|ASK_USER|ANSWER_ONLY|NO_ACTION|CALL|SEND_SMS|SET_ALARM|SET_TIMER|OPEN_URL|SET_VOLUME|APP_MESSAGE|SET_ROUTINE|READ_NOTIFICATIONS|REPLY_NOTIFICATION|ANSWER_CALL|REJECT_CALL|DAILY_BRIEF|LOG_EXPENSE|EXPENSE_REPORT|DESCRIBE_SCREEN|REMEMBER|RUN_SKILL|LEARN_SKILL|SET_SKIN",
              "target": "texto do elemento alvo na tela, ou null",
              "inputText": "texto a digitar, ou null",
              "coordinates": null,
              "requiresConfirmation": false,
              "userFacingSummary": "frase curta e natural em português explicando o que você vai fazer"
            }

            Ferramentas nativas (preferir SEMPRE a mexer na tela quando existir):
            - CALL: target = nome do contato ou número.
            - SEND_SMS: target = nome ou número; inputText = texto da mensagem.
            - SET_ALARM: target = "HH:MM" (24h); inputText = rótulo opcional.
            - SET_TIMER: target = segundos (número); inputText = rótulo opcional.
            - OPEN_URL: target = URL completa.
            - SET_VOLUME: target = percentagem 0-100.
            - OPEN_APP: target = nome do app.
            - APP_MESSAGE: mensagem DENTRO de um app (whatsapp, telegram, instagram); target = "app|contato" (ex: "whatsapp|Maria"); inputText = mensagem.
            - SET_ROUTINE: tarefa diária; target = "HH:MM"; inputText = o que fazer/lembrar. target = "cancel" remove todas. Resumo diário: SET_ROUTINE com inputText exatamente __BRIEF__.
            - READ_NOTIFICATIONS: resume e fala as notificações recentes.
            - REPLY_NOTIFICATION: target = remetente ou app; inputText = resposta.
            - ANSWER_CALL / REJECT_CALL: atende ou recusa a chamada a tocar.
            - DAILY_BRIEF: fala o resumo do dia (agenda e gastos).
            - LOG_EXPENSE: target = valor numérico; inputText = "categoria|nota". EXPENSE_REPORT: target = hoje|semana|mes.
            - DESCRIBE_SCREEN: explica/traduz o que está no ecrã; target = o pedido (ex: "traduz para português").
            - REMEMBER: guarda um facto; target = pessoa|preferencia|rotina|fato; inputText = o facto.
            - LEARN_SKILL: target = "start|nome" para aprender observando o utilizador, ou "stop". RUN_SKILL: target = nome; inputText = parâmetro.
            - SET_SKIN: target = padrao|neon|noite (aparência do avatar).
            Quando a tarefa estiver CONCLUÍDA (veja o histórico), responda ANSWER_ONLY
            confirmando em userFacingSummary. Nunca repita uma ação já bem-sucedida.
            Responda SOMENTE o objeto JSON, sem nenhum texto antes ou depois.

            Regras de raciocínio:
            - Se a tela não tiver o elemento necessário, prefira ASK_USER a chutar.
            - Se o comando for ambíguo, prefira ASK_USER.
            - Se já souber a resposta sem precisar interagir com a tela, use ANSWER_ONLY.
            - Sempre baseie "target" em texto que realmente aparece no screenText fornecido.
            - Nunca invente elementos que não estão na leitura da tela.
        """.trimIndent()
    }

    /**
     * Envia o contexto de percepção e retorna a decisão do agente.
     * Nunca lança exceção para quem chama — sempre um DecisionResult
     * explícito, com retry automático em falhas transitórias e um
     * fallback seguro (ASK_USER) quando todas as tentativas falham.
     */
    suspend fun decide(context: PerceptionContext): DecisionResult {
        var lastError: String = "erro desconhecido"

        repeat(maxRetries + 1) { attempt ->
            try {
                val decision = performRequest(context)
                return DecisionResult.Success(decision)
            } catch (e: IOException) {
                // Falha de rede/timeout: transitória, vale tentar de novo
                lastError = "Falha de rede: ${e.message}"
            } catch (e: IllegalStateException) {
                // Erro HTTP explícito (4xx/5xx) — só retenta em 5xx
                lastError = e.message ?: "Erro HTTP"
                if (!lastError.contains("50")) {
                    return DecisionResult.Failure(lastError, recoverable = false)
                }
            } catch (e: Exception) {
                // Erro de parse do JSON do modelo — não adianta retentar igual,
                // mas ainda contamos como tentativa (o modelo pode variar a saída)
                lastError = "Resposta inválida do modelo: ${e.message}"
            }

            if (attempt < maxRetries) {
                delay(500L * (attempt + 1)) // backoff simples
            }
        }

        return DecisionResult.Failure(lastError, recoverable = true)
    }

    /** Decisão de fallback segura para quando a API falha de vez. */
    fun fallbackDecision(reason: String): AgentDecision = AgentDecision(
        reasoning = "Fallback automático: $reason",
        actionType = ActionType.ASK_USER,
        requiresConfirmation = false,
        userFacingSummary = "Não consegui pensar nisso agora (problema de conexão). Pode repetir em instantes?"
    )

    /**
     * Envia um prompt cru e retorna o texto da resposta, sem exigir o
     * schema JSON de AgentDecision. Reaproveita o mesmo client/apiKey/
     * proxyBaseUrl desta instância — usado por integrações que não são
     * "decidir uma ação na tela" (ex: SelfDiagnosisAgent, que pede um
     * diagnóstico de erro em texto/diff, não um AgentDecision).
     */
    suspend fun sendRaw(systemPrompt: String, userPrompt: String): String {
        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1024)
            put("system", systemPrompt)
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "user"); put("content", userPrompt) })
            })
        }
        val bodyStr = body.toString()
        val request = if (proxyBaseUrl != null && !proxySharedSecret.isNullOrBlank()) {
            // Proxy com HMAC: assina timestamp+nonce+corpo — não é só um
            // header fixo, cada requisição tem assinatura própria (ver ProxyAuth).
            ProxyAuth.signedRequest(proxyBaseUrl, bodyStr, proxySharedSecret)
        } else {
            Request.Builder()
                .url(proxyBaseUrl ?: ENDPOINT)
                .apply { if (proxyBaseUrl == null) addHeader("x-api-key", apiKey) }
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(bodyStr.toRequestBody("application/json".toMediaType()))
                .build()
        }

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Claude API falhou: ${response.code} ${response.message}")
            }
            val raw = response.body?.string().orEmpty()
            val obj = JSONObject(raw)
            val content = obj.getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            return sb.toString().trim()
        }
    }

    /** Pergunta multimodal (screenshot em JPEG base64). O Worker encaminha p/ um modelo com visão. */
    suspend fun sendVision(prompt: String, jpegBase64: String, json: Boolean = true): String {
        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", 256)
            if (proxyBaseUrl != null) put("vision", true)
            if (proxyBaseUrl != null && !json) put("plain", true)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().apply {
                            put("type", "image")
                            put("source", JSONObject().apply {
                                put("type", "base64"); put("media_type", "image/jpeg"); put("data", jpegBase64)
                            })
                        })
                        put(JSONObject().apply { put("type", "text"); put("text", prompt) })
                    })
                })
            })
        }
        val bodyStr = body.toString()
        val request = if (proxyBaseUrl != null && !proxySharedSecret.isNullOrBlank()) {
            ProxyAuth.signedRequest(proxyBaseUrl, bodyStr, proxySharedSecret)
        } else {
            Request.Builder().url(proxyBaseUrl ?: ENDPOINT)
                .apply { if (proxyBaseUrl == null) addHeader("x-api-key", apiKey) }
                .addHeader("anthropic-version", "2023-06-01").addHeader("content-type", "application/json")
                .post(bodyStr.toRequestBody("application/json".toMediaType())).build()
        }
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Visão falhou: ${response.code}")
            return extractTextFromResponse(response.body?.string().orEmpty())
        }
    }

    private fun performRequest(context: PerceptionContext): AgentDecision {
        val userPrompt = buildUserPrompt(context)

        val body = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1024)
            put("system", SYSTEM_PROMPT)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", userPrompt)
                })
            })
        }

        // Com proxy + secret configurados, a requisição é assinada com HMAC
        // (timestamp+nonce+corpo) — não é mais um header fixo comparável
        // por qualquer um que capture uma requisição antiga (replay).
        val bodyStr = body.toString()
        val request = if (proxyBaseUrl != null && !proxySharedSecret.isNullOrBlank()) {
            ProxyAuth.signedRequest(proxyBaseUrl, bodyStr, proxySharedSecret)
        } else {
            Request.Builder()
                .url(proxyBaseUrl ?: ENDPOINT)
                .apply { if (proxyBaseUrl == null) addHeader("x-api-key", apiKey) }
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(bodyStr.toRequestBody("application/json".toMediaType()))
                .build()
        }

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Claude API falhou: ${response.code} ${response.message}")
            }
            val raw = response.body?.string().orEmpty()
            val text = extractTextFromResponse(raw)
            return parseDecision(text)
        }
    }

    internal fun buildUserPrompt(ctx: PerceptionContext): String {
        val historyStr = ctx.recentHistory.takeLast(5).joinToString("\n") {
            "- [${it.outcome}] ${it.decision.userFacingSummary}"
        }
        val memoriesStr = ctx.relevantMemories.joinToString("\n") {
            "- (${it.category}, confiança=${it.confidence}) ${it.content}"
        }

        return """
            APP ATUAL: ${ctx.currentApp}
            SKILLS ENSINADAS: ${com.example.jarvis.skills.SkillStore.catalog.ifBlank { "(nenhuma)" }}

            COMANDO DO USUÁRIO: ${ctx.userCommand ?: "(nenhum — modo autônomo, observando)"}

            LEITURA DA TELA:
            ${ctx.screenText.take(4000)}

            HISTÓRICO RECENTE DE AÇÕES:
            ${historyStr.ifBlank { "(sem histórico ainda)" }}

            MEMÓRIAS RELEVANTES SOBRE O USUÁRIO:
            ${memoriesStr.ifBlank { "(nenhuma memória relevante recuperada)" }}

            Decida a próxima ação. Responda apenas o JSON.
        """.trimIndent()
    }

    private fun extractTextFromResponse(raw: String): String {
        val obj = JSONObject(raw)
        val content = obj.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") {
                sb.append(block.optString("text"))
            }
        }
        return sb.toString().trim()
    }

    internal fun parseDecision(rawJson: String): AgentDecision {
        // Remove possíveis fences de markdown que o modelo às vezes adiciona
        // Modelos pequenos/gratuitos às vezes cercam o JSON com texto: pega do primeiro { ao último }.
        val start = rawJson.indexOf('{')
        val end = rawJson.lastIndexOf('}')
        val cleaned = if (start in 0 until end) rawJson.substring(start, end + 1) else rawJson.trim()
        return json.decodeFromString(cleaned)
    }
}
