// ============================================================
// selfupdate/UpdateChecker.kt
// ------------------------------------------------------------
// "Autoatualização" do próprio app, dentro do que o Android
// realmente permite: checar se existe versão nova, baixar o
// APK, e abrir o instalador do sistema — que SEMPRE pede
// confirmação do usuário antes de instalar, mesmo pra apps
// fora da Play Store. Isso não é limitação deste código, é
// o modelo de segurança do Android (PackageInstaller exige
// consentimento explícito na UI do sistema).
//
// Não existe "silent update" possível aqui sem o app ser um
// app de sistema com assinatura de plataforma — não é o caso
// de um app sideload como o Jarvis.
// ============================================================

package com.example.jarvis.selfupdate

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

data class VersaoDisponivel(
    val versionCode: Int,
    val versionName: String,
    val urlApk: String,
    val changelog: String
)

interface UpdateCheckPort {
    /** Consulta um endpoint que você controla (ex: seu backend-proxy) com o manifesto da versão atual. */
    suspend fun checarVersaoMaisRecente(): VersaoDisponivel?
}

class UpdateChecker(
    private val context: Context,
    private val port: UpdateCheckPort,
    private val versionCodeAtual: Int
) {
    suspend fun verificarEAvisar(): VersaoDisponivel? {
        val disponivel = port.checarVersaoMaisRecente() ?: return null
        return if (disponivel.versionCode > versionCodeAtual) disponivel else null
    }

    /**
     * Baixa o APK e abre o instalador do sistema. O parâmetro de
     * retorno indica só se o download/preparação funcionou — a
     * decisão de instalar de fato acontece na tela do Android,
     * fora do controle deste código.
     */
    fun prepararInstalacao(apkFile: File): Intent {
        val uri = FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", apkFile
        )
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
