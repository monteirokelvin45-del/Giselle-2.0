// ============================================================
// voice/WakeWordConfig.kt
// ------------------------------------------------------------
// Única lógica do WakeWordService que é pura (não depende do
// SDK nativo da Picovoice nem de Android) — extraída para ser
// testável. O resto (PorcupineManager, microfone real) exige a
// biblioteca nativa real da Picovoice; não há como simular isso
// de forma honesta sem o SDK deles rodando de verdade, então
// fica fora da cobertura de teste por limite genuíno, não por
// preguiça.
// ============================================================

package com.example.jarvis.voice

object WakeWordConfig {
    fun isConfigured(accessKey: String): Boolean = accessKey.isNotBlank()
}
