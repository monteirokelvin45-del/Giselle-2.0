// ============================================================
// core/SafetyGate.kt
// ------------------------------------------------------------
// PRINCÍPIO DE DESIGN (não negociável): o LLM decide O QUE fazer,
// mas NUNCA decide se precisa de confirmação. Essa decisão é
// hard-coded aqui, fora do alcance de prompt injection ou
// alucinação do modelo. Isso é o que separa um assistente
// confiável de um risco de segurança.
// ============================================================

package com.example.jarvis.core

object SafetyGate {

    // Ações que são SEMPRE irreversíveis, não importa o app
    private val hardBlockedActions = setOf(
        "deletar", "excluir", "apagar", "delete", "remover conta",
        "formatar", "reset de fábrica"
    )

    // Apps que envolvem dinheiro ou terceiros = risco elevado por padrão
    private val sensitiveAppPatterns = listOf(
        "nubank", "itau", "bradesco", "santander", "picpay", "mercadopago",
        "whatsapp", "telegram", "instagram", "gmail", "outlook",
        "ifood", "rappi", "uber", "99", "amazon", "mercadolivre", "shopee"
    )

    // Palavras que indicam ação de envio/compra/publicação (irreversível ou pública)
    private val irreversibleIntentPatterns = listOf(
        "enviar", "mandar", "comprar", "pagar", "transferir", "publicar",
        "postar", "confirmar pedido", "finalizar compra", "assinar"
    )

    fun evaluate(decision: AgentDecision, currentApp: String): RiskLevel {
        val target = (decision.target ?: "").lowercase()
        val summary = decision.userFacingSummary.lowercase()
        val app = currentApp.lowercase()

        // 1. Bloqueio duro: nunca passa sem confirmação, ponto final
        if (hardBlockedActions.any { target.contains(it) || summary.contains(it) }) {
            return RiskLevel.IRREVERSIBLE
        }

        // 2. App sensível + intenção de ação irreversível = confirma
        val isAppSensitive = sensitiveAppPatterns.any { app.contains(it) }
        val hasIrreversibleIntent = irreversibleIntentPatterns.any {
            target.contains(it) || summary.contains(it)
        }
        if (isAppSensitive && hasIrreversibleIntent) {
            return RiskLevel.SENSITIVE
        }

        // 3. Digitar texto em campos de senha/dados sensíveis
        if (decision.actionType == ActionType.CALL || decision.actionType == ActionType.SEND_SMS ||
            decision.actionType == ActionType.APP_MESSAGE ||
            decision.actionType == ActionType.REPLY_NOTIFICATION || decision.actionType == ActionType.ANSWER_CALL) {
            return RiskLevel.SENSITIVE
        }

        if (decision.actionType == ActionType.TYPE_TEXT &&
            (target.contains("senha") || target.contains("cvv") || target.contains("cpf"))
        ) {
            return RiskLevel.SENSITIVE
        }

        // 4. Tudo mais (navegar, ler, organizar, abrir apps) = seguro, autonomia total
        return RiskLevel.SAFE
    }

    /**
     * Aplica a avaliação sobre a decisão do LLM, sobrescrevendo
     * requiresConfirmation independente do que o modelo tenha sugerido.
     */
    fun apply(decision: AgentDecision, currentApp: String): AgentDecision {
        val risk = evaluate(decision, currentApp)
        val requiresConfirmation = risk != RiskLevel.SAFE
        return decision.copy(requiresConfirmation = requiresConfirmation)
    }
}
