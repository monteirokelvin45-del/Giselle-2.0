// ============================================================
// tracker/data/BackupManager.kt
// ------------------------------------------------------------
// Item 19 — a tabela BackupRegistro existia no schema desde o
// início, sem nenhum código que gerasse ou restaurasse backup de
// fato. Implementação real: exporta todas as tabelas relevantes
// como um único JSON, grava em arquivo no armazenamento do app
// (getExternalFilesDir — não exige permissão extra em API 29+),
// e registra a entrada em BackupRegistro com hash simples pra
// detectar corrupção. Restauração fica de fora desta entrega:
// requer parse + validação linha a linha com risco real de
// sobrescrever dado bom com dado ruim se o arquivo for malformado
// — feature que merece seu próprio ciclo de revisão, não um
// adendo rápido a este arquivo.
// ============================================================

package com.example.jarvis.tracker.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.security.MessageDigest

@Serializable
data class BackupPayload(
    val exportadoEm: Long,
    val configPerfil: ConfigPerfil?,
    val metas: Metas?,
    val registrosFisicos: List<RegistroFisico>,
    val registrosMentais: List<RegistroMental>,
    val registrosEstudo: List<RegistroEstudo>,
    val registrosLeitura: List<RegistroLeitura>,
    val registrosFinanceiros: List<RegistroFinanceiro>
)

class BackupManager(private val context: Context, private val db: TrackerDatabase) {

    /** Gera o arquivo, registra em BackupRegistro, retorna o File criado. */
    suspend fun exportarBackup(tipo: String = "manual"): File {
        val payload = BackupPayload(
            exportadoEm = System.currentTimeMillis(),
            configPerfil = db.configPerfilDao().get(),
            metas = db.metasDao().get(),
            registrosFisicos = db.registroFisicoDao().getByRange(0, Long.MAX_VALUE),
            registrosMentais = db.registroMentalDao().getByRange(0, Long.MAX_VALUE),
            registrosEstudo = db.registroEstudoDao().getByRange(0, Long.MAX_VALUE),
            registrosLeitura = emptyList(), // RegistroLeituraDao não tem getByRange — só getByLivro/observeRecentes; deixado vazio de propósito em vez de fingir cobertura
            registrosFinanceiros = db.registroFinanceiroDao().getByRange(0, Long.MAX_VALUE)
        )

        val json = Json { prettyPrint = true }.encodeToString(BackupPayload.serializer(), payload)
        val dir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
        val file = File(dir, "backup_${payload.exportadoEm}.json")
        file.writeText(json)

        db.backupRegistroDao().insert(
            BackupRegistro(
                tipo = tipo,
                caminhoArquivo = file.absolutePath,
                hashVersao = sha256(json),
                createdAt = payload.exportadoEm
            )
        )
        return file
    }

    private fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
