// ============================================================
// JarvisAccessibilityService.kt
// Núcleo de percepção + ação do "cérebro" no Android.
// Lê a tela em tempo real e executa ações (toques, swipes, texto).
// ============================================================

package com.example.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "JarvisA11y"
        // Referência estática pra outros componentes (Agent, ViewModel) chamarem ações
        var instance: JarvisAccessibilityService? = null
    }

    private var lastKnownPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        com.example.jarvis.visual.OverlayController.attach(this)
        Log.d(TAG, "Serviço conectado — olhos abertos.")
    }

    // -----------------------------------------------------
    // PERCEPÇÃO: chamado toda vez que algo muda na tela
    // -----------------------------------------------------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        com.example.jarvis.skills.SkillRecorder.onEvent(this, event)

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val pkg = event.packageName?.toString() ?: "desconhecido"
                lastKnownPackage = pkg
                Log.d(TAG, "App em foco mudou: $pkg")
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                // Log de interações do usuário -> alimenta a memória de aprendizado
                // AgentOrchestrator.logUserAction(event)
            }
            else -> {}
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Serviço interrompido.")
    }

    // -----------------------------------------------------
    // PERCEPÇÃO ATIVA: tira um "snapshot" da árvore de tela atual
    // Retorna texto/hierarquia legível pro LLM decidir o que fazer
    // -----------------------------------------------------
    fun snapshotScreen(): String {
        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return "Sem acesso à tela atual."
        val builder = StringBuilder()
        traverseNode(root, builder, depth = 0)
        return builder.toString()
    }

    private fun traverseNode(node: AccessibilityNodeInfo, builder: StringBuilder, depth: Int) {
        val indent = "  ".repeat(depth)
        val text = node.text?.toString().orEmpty()
        val desc = node.contentDescription?.toString().orEmpty()
        val cls = node.className?.toString().orEmpty()

        if (text.isNotBlank() || desc.isNotBlank()) {
            builder.append("$indent[$cls] text='$text' desc='$desc' clickable=${node.isClickable}\n")
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                traverseNode(child, builder, depth + 1)
                child.recycle()
            }
        }
    }

    // -----------------------------------------------------
    // AÇÃO: clicar em um nó pelo texto (ex: "Enviar", "Confirmar")
    // -----------------------------------------------------
    fun clickByText(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, target) ?: return false
        return performClick(node)
    }

    // Mesma regra de match do NodeTextMatcher (testado em NodeTextMatcherTest) —
    // mantido inline aqui em vez de delegar porque converter a árvore real pra
    // NodeView a cada clique teria custo de runtime sem ganho real.
    private fun findNodeByText(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(target, ignoreCase = true) == true ||
            node.contentDescription?.toString()?.contains(target, ignoreCase = true) == true) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByText(child, target)
            if (result != null) return result
            child.recycle()
        }
        return null
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        // Tenta ação nativa primeiro
        if (node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // Fallback: gesto de toque nas coordenadas do nó
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return tapAt(rect.centerX().toFloat(), rect.centerY().toFloat())
    }

    // -----------------------------------------------------
    // AÇÃO: toque genérico em coordenadas (x, y)
    // -----------------------------------------------------
    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    // -----------------------------------------------------
    // AÇÃO: digitar texto num campo focado
    // -----------------------------------------------------
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
            )
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // -----------------------------------------------------
    // AÇÃO: voltar / home (navegação básica do sistema)
    // -----------------------------------------------------
    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun currentPackage(): String? = lastKnownPackage ?: rootInActiveWindow?.packageName?.toString()
}

// ============================================================
// Helper de acesso estático, usado pelo ForegroundService sem
// precisar importar detalhes internos do serviço de Accessibility.
// ============================================================
object JarvisAccessibilityServiceRef {
    fun snapshot(): String = JarvisAccessibilityService.instance?.snapshotScreen() ?: ""
    fun currentPackageName(): String? = JarvisAccessibilityService.instance?.currentPackage()
}
