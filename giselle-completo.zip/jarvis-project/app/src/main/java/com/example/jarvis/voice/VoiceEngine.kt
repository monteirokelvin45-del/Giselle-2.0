// ============================================================
// voice/VoiceEngine.kt
// ------------------------------------------------------------
// STT via SpeechRecognizer nativo do Android (grátis, offline
// em muitos devices). TTS via TextToSpeech nativo.
// Para STT de qualidade superior (ex: Whisper), trocar por
// chamada à API — deixei o hook pronto em transcribeViaWhisper().
// ============================================================

package com.example.jarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.jarvis.core.GiselleBus
import com.example.jarvis.core.GiselleState
import java.util.Locale

class VoiceEngine(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun init() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) = finishOne()
                    override fun onError(id: String?) = finishOne()
                    // pulso por palavra: aproxima o "ritmo da voz" até haver TTS próprio (Piper)
                    override fun onRangeStart(id: String?, start: Int, end: Int, frame: Int) { GiselleBus.pulse() }
                })
            }
        }
    }

    fun speak(text: String) {
        if (!ttsReady) return
        GiselleBus.pendingSpeech.incrementAndGet()
        GiselleBus.set(GiselleState.SPEAKING)
        GiselleBus.say(text)
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "jarvis_utterance_${System.currentTimeMillis()}")
    }

    /**
     * Escuta um único comando de voz e retorna via callback.
     * Uso: acionado por wake word externa ou botão físico/UI.
     */
    fun listenOnce(onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Reconhecimento de voz não disponível neste device.")
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()
                    if (text != null) onResult(text) else onError("Não entendi.")
                }

                override fun onError(error: Int) {
                    onError("Erro de reconhecimento: código $error")
                }

                // Callbacks obrigatórios sem ação necessária aqui
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            }
            startListening(intent)
        }
    }

    private fun finishOne() {
        if (GiselleBus.pendingSpeech.decrementAndGet() <= 0) {
            GiselleBus.pendingSpeech.set(0)
            if (!GiselleBus.taskActive) GiselleBus.set(GiselleState.IDLE)
        }
    }

    fun destroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
    }

    // Hook para trocar por Whisper API se quiser precisão maior
    // suspend fun transcribeViaWhisper(audioFile: File): String { ... }
}
