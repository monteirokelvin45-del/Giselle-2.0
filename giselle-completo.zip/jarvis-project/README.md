# Jarvis — Assistente Autônomo Android

Esqueleto de arquitetura completa para um assistente tipo JARVIS:
percebe a tela em tempo real, raciocina com Claude, age em qualquer
app via Accessibility, aprende com o uso e evolui a memória ao longo
do tempo.

## Arquitetura (fluxo de decisão)

```
┌─────────────────────┐
│ AccessibilityService │  ← PERCEPÇÃO + AÇÃO
│  (lê tela, executa)  │
└──────────┬───────────┘
           │ screenSnapshot + evento
           ▼
┌─────────────────────┐
│ JarvisForegroundService │  ← mantém tudo vivo em background
└──────────┬───────────┘
           │
           ▼
┌─────────────────────┐
│  AgentOrchestrator    │  ← O MAESTRO
│  1. recall (memória)  │
│  2. monta contexto    │
│  3. chama Claude       │
│  4. SafetyGate valida  │
│  5. executa ou enfileira confirmação
│  6. loga + aprende     │
└──┬────────┬────────┬──┘
   │        │        │
   ▼        ▼        ▼
ClaudeClient  MemoryStore  SafetyGate
(raciocínio)  (Room+vetor)  (hard-coded,
                             LLM não decide isso)
```

## Módulos

| Módulo | Responsabilidade |
|---|---|
| `accessibility/` | Percepção da tela + execução de ações (clique, texto, swipe) |
| `agent/` | Orquestrador — conecta todas as peças |
| `core/` | Modelos de dados, SafetyGate, ForegroundService |
| `llm/` | Cliente da Claude API, prompt engineering |
| `memory/` | Persistência (Room) + busca por similaridade (embeddings) |
| `voice/` | STT/TTS nativos do Android |

## Decisão de segurança (não é feature, é fundação)

O LLM **nunca** decide sozinho se uma ação precisa de confirmação.
Isso é avaliado pelo `SafetyGate`, um módulo hard-coded e determinístico,
fora do alcance de prompt injection ou alucinação do modelo.

- Ações de leitura, navegação, organização → **autonomia total**
- Ações que envolvem dinheiro, terceiros ou dados sensíveis, ou que
  sejam irreversíveis (enviar, pagar, deletar, publicar) → **sempre
  pedem confirmação**, mesmo que o LLM ache que não precisa.

Isso não é uma limitação temporária — é uma decisão de design que
deve permanecer mesmo com o sistema maduro. Autonomia total em ações
irreversíveis é o tipo de coisa que parece boa ideia até a primeira
mensagem errada enviada pro contato errado.

## O que já está funcional neste esqueleto

- [x] Leitura de tela em tempo real via AccessibilityService
- [x] Execução de ações (clique por texto, digitar, navegar)
- [x] Integração estruturada com Claude API (JSON forçado)
- [x] Memória de longo prazo com Room + busca por similaridade
- [x] Sistema de reforço de memória (confiança cresce com repetição)
- [x] Gate de segurança determinístico, independente do LLM
- [x] Foreground Service pra rodar em background
- [x] STT/TTS nativos
- [x] **Abrir apps de verdade** (`AppLauncher`, via PackageManager + matching de nome)
- [x] **Embeddings reais** via Voyage AI (`VoyageEmbedder`), com fallback dev se a key não estiver configurada
- [x] **API key fora do código** — lida de `local.properties` via `BuildConfig`, nunca hard-coded
- [x] **UI de confirmação de ações** — aba dedicada em Compose, aprovar/rejeitar
- [x] **Painel de memórias** — aba mostrando tudo que o sistema aprendeu, com confiança
- [x] **Wake word contínuo** via Porcupine (opcional, requer AccessKey + modelo `.ppn` treinado)
- [x] **Rate limiting + circuit breaker** no orquestrador — protege contra loop de custo/ações descontroladas
- [x] **Log auditável** — tabela `audit_log` separada da memória de aprendizado, append-only, com toda decisão/execução
- [x] **Testes unitários do SafetyGate** — o componente de maior risco tem a cobertura mais explícita
- [x] **Timeout/fallback na Claude API** — retry com backoff, `DecisionResult` explícito, resposta segura se tudo falhar

## Configuração das API keys

Copie `local.properties.template` para `local.properties` (nunca commitado, já no `.gitignore`) e preencha:

```
CLAUDE_API_KEY=sua_key_da_anthropic
VOYAGE_API_KEY=sua_key_da_voyage_ai   # opcional — sem ela, usa embedder de teste
```

**Nota de segurança**: mesmo via `BuildConfig`, a key ainda fica embutida no APK compilado
e pode ser extraída por quem decompilar o app. Isso é aceitável para uso pessoal via
sideload. Para qualquer distribuição além disso, use o **backend proxy** (já implementado
em `backend-proxy/`, ver seção abaixo) — sua key nunca toca o device do usuário final.

## Backend proxy (opcional, mas já pronto) — `backend-proxy/`

Cloudflare Worker que guarda a `CLAUDE_API_KEY` só no servidor. Autenticação por
HMAC-SHA256 (timestamp + nonce + corpo assinados a cada requisição — não é um
header fixo que dá pra reaproveitar se vazar), rate limiting nativo do Cloudflare,
e anti-replay via KV (funciona entre isolates diferentes, não só um `Map` em memória
por instância).

**Setup (rode a partir de `backend-proxy/`):**
```
npm install -g wrangler
wrangler login
wrangler kv namespace create NONCES        # cole o "id" retornado em wrangler.toml
python3 provision.py                       # gera o PROXY_SHARED_SECRET e preenche local.properties
wrangler deploy
wrangler secret put ANTHROPIC_API_KEY      # cole sua CLAUDE_API_KEY
wrangler secret put PROXY_SHARED_SECRET    # cole o valor que o provision.py gerou
```
Depois disso, `PROXY_BASE_URL` já está preenchido no `local.properties` (saída do
`wrangler deploy`) e o app passa a assinar cada requisição via `ProxyAuth.kt` em vez
de mandar a key direto pra Anthropic.

**Rotação do secret sem downtime**: `python3 provision.py --rotate` — gera um
`PROXY_SHARED_SECRET_NEXT`, o Worker aceita o secret antigo E o novo durante a
transição, e o script imprime o runbook exato dos comandos `wrangler` a rodar.
**Auditoria sem alterar nada**: `python3 provision.py --check`.

## Wake word ("Ei Jarvis") — o que falta pra ativar

1. Crie uma conta gratuita em console.picovoice.ai
2. Treine uma wake word customizada "Jarvis" (ou outra palavra) — gera um arquivo `.ppn`
3. Coloque o `.ppn` em `app/src/main/assets/jarvis_wake_word.ppn`
4. Cole sua AccessKey em `WakeWordService.PICOVOICE_ACCESS_KEY` (idealmente via `local.properties` também)
5. Inicie o `WakeWordService` a partir da `MainActivity` (ainda não é automático — decisão sua se quer que rode sempre)

Sem isso configurado, o app funciona 100% normalmente por texto e toque no microfone —
wake word é um extra, não uma dependência.

## Rodando os testes

```
./gradlew testDebugUnitTest
```

Cobre o `SafetyGate` (ações seguras, bloqueio duro, apps sensíveis, campos sensíveis,
e a garantia de que `apply()` sempre sobrescreve o que o LLM sugeriu) — o componente
que, se quebrar silenciosamente, tem o maior custo.

**Atualização**: `AgentOrchestrator`, `AppLauncher` e `CircuitBreaker` também já têm
suite própria (`AgentOrchestratorTest.kt`, `AppLauncherTest.kt`, `CircuitBreakerTest.kt`).
A seção abaixo ("o que ainda falta") estava desatualizada nesse ponto — corrigida.

## O que ainda falta — e por que não finjo que está pronto

1. **UI de confirmação e painel de memórias**: já implementados — mas se você
   quiser evoluir, itens naturais são: swipe-to-dismiss, busca/filtro nas
   memórias, e edição manual (deletar uma memória errada direto na tela).

2. **`OPEN_APP`**: implementado via `AppLauncher`, mas o matching de nome
   ("abre o whats") é por texto aproximado — não é perfeito com apps de
   nome muito genérico ou ambíguo. Testar e ajustar conforme o uso real.

3. **Wake word**: o código está pronto, mas depende de você treinar o
   modelo `.ppn` no console da Picovoice — não é algo que dá pra deixar
   "genérico" no repositório.

4. **Backend proxy pra API key**: implementado em `backend-proxy/` (Worker +
   `provision.py` + `ProxyAuth.kt` no app) — HMAC assinado, rate limit,
   anti-replay via KV, rotação sem downtime. Só falta você rodar o deploy
   (ver seção "Backend proxy" acima) — sem isso, o app usa a API direto,
   o que já é o comportamento padrão e funciona normalmente.

5. **Cobertura de testes**: só o `SafetyGate` tem testes por enquanto.
   `AgentOrchestrator`, `AppLauncher` e `CircuitBreaker` ainda não têm
   suite própria — são os próximos com melhor custo-benefício de cobrir.

## Como rodar

0. Rode `./setup.sh` na raiz do projeto — valida o Gradle Wrapper e
   checa se as API keys em `local.properties` estão preenchidas.
1. Abra no Android Studio (Hedgehog+)
2. Copie `local.properties.template` → `local.properties` e preencha `CLAUDE_API_KEY`
   (e opcionalmente `VOYAGE_API_KEY`)
3. Build → instale via USB (sideload)
4. Ative manualmente: Configurações → Acessibilidade → Jarvis → Ativar
5. Conceda permissão de notificações e microfone quando solicitado

## Próximo passo recomendado

Cobrir `AgentOrchestrator` com testes (o fluxo completo: rate limit → circuit
breaker → decisão → safety gate → execução → log). O backend proxy já está
pronto — só falta rodar o deploy quando/se quiser distribuir além de uso pessoal.
