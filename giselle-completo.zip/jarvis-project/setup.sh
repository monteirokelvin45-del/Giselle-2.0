#!/usr/bin/env bash
# ============================================================
# setup.sh — roda no SEU computador, não no ambiente do Claude.
#
# Resolve o único bloqueador que não pode ser resolvido em código:
# o gradle-wrapper.jar (binário compilado, precisa de Gradle real
# ou Android Studio instalado). Depois disso, valida o resto do
# setup que já está pronto no projeto.
#
# Uso:
#   chmod +x setup.sh && ./setup.sh
# ============================================================

set -e

echo "== 1/4: Gradle Wrapper =="
if [ -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo "  OK — já existe."
else
    if command -v gradle >/dev/null 2>&1; then
        echo "  Gradle encontrado, gerando wrapper..."
        gradle wrapper --gradle-version 8.7
        echo "  OK — gradle-wrapper.jar criado."
    else
        echo "  Gradle não está instalado no PATH."
        echo "  → Abra este projeto no Android Studio: ele detecta o"
        echo "    wrapper incompleto e regenera sozinho na primeira sincronização."
        echo "  → Ou instale Gradle (https://gradle.org/install) e rode este script de novo."
    fi
fi

echo ""
echo "== 2/4: API key da Claude =="
if grep -q "CLAUDE_API_KEY=$" local.properties 2>/dev/null || ! grep -q "CLAUDE_API_KEY=" local.properties 2>/dev/null; then
    echo "  ATENÇÃO — CLAUDE_API_KEY não está preenchida em local.properties."
    echo "  Sem ela, o Orchestrator (núcleo e tracker) trava na primeira chamada."
else
    echo "  OK — chave presente em local.properties."
fi

echo ""
echo "== 3/4: Chaves opcionais (degradam graciosamente se ausentes) =="
for key in VOYAGE_API_KEY PICOVOICE_ACCESS_KEY; do
    if grep -q "^${key}=.\+" local.properties 2>/dev/null; then
        echo "  $key: presente"
    else
        echo "  $key: ausente (ok — funcionalidade correspondente fica desativada)"
    fi
done

echo ""
echo "== 4/4: Permissões do wrapper =="
chmod +x gradlew 2>/dev/null && echo "  gradlew marcado como executável."

echo ""
echo "== Resumo =="
if [ -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo "  Pronto para: ./gradlew build"
else
    echo "  Ainda falta resolver o wrapper (ver passo 1 acima) antes de buildar."
fi
